#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<>

class Human:
    # 属性
    sex = '男'
    age = 25
    name = '张三'
    height = '178cm'
    def eat(self):
        print("吃饭功能")

    pass














