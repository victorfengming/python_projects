#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<升级版本>


# 水果类
class Fruit:
    pass

# 南方类
class South:
    pass

# 北方类
class North:
    pass




# 苹果类

class Apple(Fruit):
    pass

# lidelei
class Pear(Fruit):
    pass

# 香蕉
class Banana(Fruit):
    pass


# 桔子
class Orange(Fruit):
    pass















'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
