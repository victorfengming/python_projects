#print是函数

#第一次调用print()
print('老娘跟你拼了！',end = '')

#第二次调用
print('你跟老娘跑了！')

#第三次调用
print('你跟老娘跑了！')
