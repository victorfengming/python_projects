#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<定义求和函数>

def sum_100():
    res = 0
    for i in range(1,101):
        res += i
    print(res)

sum_100()






