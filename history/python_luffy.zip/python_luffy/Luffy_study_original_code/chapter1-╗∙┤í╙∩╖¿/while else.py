#_*_coding:utf-8_*_



count = 0
while count <= 5:
    print('loop ',count)
    if count == 3:
        break
    count +=1
else:
    print('loop is done...')

print('out of loop ')