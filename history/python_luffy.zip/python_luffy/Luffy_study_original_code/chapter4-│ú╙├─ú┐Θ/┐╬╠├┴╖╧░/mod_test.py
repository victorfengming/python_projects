#_*_coding:utf-8_*_

from mods.core import sayhi


sayhi()