#_*_coding:utf-8_*_



import pickle,json

#
# d = {'name':'alex','age':22}
#
# l = [1,2,3,4,'rain']


def syahi():
    print('dddd')




# pk = open("data.pkl","wb")
#
# pickle.dump(d,pk)
#
# f = open("data.pkl","rb")
#
# d = pickle.load(f)
# print(d)

pickle.dumps(syahi)

json.dumps(syahi)