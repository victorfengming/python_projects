

f = open("兼职白领学生空姐模特护士联系方式.txt",'ab')
f.write("\n肛娘    北京  167  55  13523230322".encode("gbk"))

f.close()