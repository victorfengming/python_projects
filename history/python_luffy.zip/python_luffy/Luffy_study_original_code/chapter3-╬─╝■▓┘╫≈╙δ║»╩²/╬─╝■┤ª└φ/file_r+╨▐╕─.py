#_*_coding:utf-8_*_

f = open("兼职白领学生空姐模特护士联系方式.txt",'r+')


f.seek(10)

f.write("[路飞学城 luffycity]")
f.close()