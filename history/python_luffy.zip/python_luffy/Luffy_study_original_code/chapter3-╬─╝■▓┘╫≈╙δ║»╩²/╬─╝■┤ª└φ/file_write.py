

f = open("兼职.txt",'wb')
f.write("原子二号".encode("gbk"))

f.close()