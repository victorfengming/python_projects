#_*_coding:utf-8_*_



d = [1,2,3]
def run():
    d[1] = 2222
    print(d)

run()
print(d)