#_*_coding:utf-8_*_



def stu_register(name,age,course):

    print(name,age,course)
    #
    # if age > 22:
    #     return 'sdfsf'
    # else:
    #     return True
    return [name,age]

status = stu_register('Peiqi',29,'安保')
print(status)
