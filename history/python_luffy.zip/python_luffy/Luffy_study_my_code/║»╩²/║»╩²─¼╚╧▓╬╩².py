# def s(name,age,course,country="CN"):
#     print("---注册学生信息---")
#     print("姓名：",name)
#     print("年龄：",age)
#     print("国籍:",country)
#     print("课程:",course)
# s()
# def s(name,age,course,country="CN"):
#     s("1","2","3","4")
def s(name,age,course,country="CN"):
    print("---注册学生信息---")
    print("姓名：",name)
    print("年龄：",age)
    print("国籍:",country)
    print("课程:",course)
# s()
# def s(name,age,course,country="CN"):
    s("1","2","3")
