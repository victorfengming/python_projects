# 匿名函数
# def calc(x,y):
#     if x>y :
#         return x * y
#     else :
#         x/y
# calc(8,2)
# func = lambda x,y:x*y
# print(calc(3,8))
# print(func(3,8))
map()