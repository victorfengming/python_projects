locals()
globals()
frozenset()
zip()
