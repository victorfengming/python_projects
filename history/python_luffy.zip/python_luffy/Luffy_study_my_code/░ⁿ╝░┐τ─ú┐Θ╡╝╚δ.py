要养成建立目录的好习惯
做什么项目都是这样
包就是比模块更大的一个级别的目录
from crm import views
views
