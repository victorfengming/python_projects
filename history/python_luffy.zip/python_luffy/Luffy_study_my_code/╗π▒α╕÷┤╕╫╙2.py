for i in range(1,1000):
    for j in range(1,1000):
        for k in range(1,1000):
            if i**3+j**3==k**3:
                print("ok")
print("end")
#找不着
#还是费马nb