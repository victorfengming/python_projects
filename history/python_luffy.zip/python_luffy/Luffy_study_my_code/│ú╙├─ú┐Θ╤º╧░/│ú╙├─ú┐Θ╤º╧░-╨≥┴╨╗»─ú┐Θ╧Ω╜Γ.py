本节重点：
    是学员掌握json&pickle模块的使用
    本节时长需控制在20分钟内
什么叫序列化？
    序列化是指把内存里的数据类型转变成字符串，以使其能存储到硬盘或通过网络传输到远程，因为硬盘或网络传输时只能接受bytes
为什么要序列化？
    为什么要把内存里的数据存到硬盘上
    在你玩游戏的时候中断，程序暂时关掉，可以继续使用。


    用于序列化的两个模块
        json,用于字符串和python数据类型进行转换
        pickle，用于python特有的数据类型和python的数据类型间进行转换
    json模块提供了四个功能：dumps、dump、loads、load
    json模块提供了四个功能：dumps、dump、loads、load
    pickle，用于python特有的类型和python的数据类型间进行转换
        __import__() pickle
