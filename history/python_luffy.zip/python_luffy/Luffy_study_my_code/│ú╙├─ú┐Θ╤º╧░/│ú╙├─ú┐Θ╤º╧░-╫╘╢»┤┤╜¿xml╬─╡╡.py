import xml.etree.ElementTree as ET
new_xml = ET.Element("namelist")


