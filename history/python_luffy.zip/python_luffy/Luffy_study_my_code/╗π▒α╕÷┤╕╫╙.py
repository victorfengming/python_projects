a = input("qingshuru:")
if a<"z" and a>"a" :
    print(a.upper())
elif a<"Z" and a>"A":
    print(a.lower())
else:
    print("*")