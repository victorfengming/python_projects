import time
myD = {1:'a',2:'b'}
for key,value in dict.items(myD):
	print (key,value)
	time.sleep(2)#延迟两秒再输出