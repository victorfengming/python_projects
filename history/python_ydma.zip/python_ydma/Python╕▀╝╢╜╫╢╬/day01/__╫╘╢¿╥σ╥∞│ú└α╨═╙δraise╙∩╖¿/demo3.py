#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<>

try:
    print(a)
    # 此处出现了异常的时候我们没有任何操作,系统异常类型,会出现的时候自动抛出

except:
    print('程序出现了异常')















'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
