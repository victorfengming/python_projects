#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<>


# 系统异常类
help(Exception)

# 基础异常类
help(BaseException)

# 里面全是一些魔术方法
# 大体上她俩是一样的,那我们要是想自己定义异常,必须站在巨人的肩膀上












'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
