#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<>

print('''
1,2,3,4,5
6,7,8,9,10
11,12,13,14,15


''')
a = 1
# a = 1
b = 3
#
# # ==5
# print(var)
# # !=5
# print(var,end="")

# 功能:
# 参数:无/有
# 返回值:无/有
#
# i.func()
# i.func('ninds')
# res = i.func()
# res = i.func('insing')
#
# i = (2,4)
# res = sum(i)
# print(res)
#
# listt = [2,3,4]
# res = max(listt)
# print(res)


#
# listt = [2,3,4]
# # print(listt)
# print(listt.copy())
# # print(res)
# print(max(listt))

# *收集参数
# def func(*args,**你大爷):
#     print('sfdfhg')
    # print(len(args))
    # 判断args有没有东覀
    # print(min(args))
    # for i in 你大爷.values():
    #     print(i)


# func()








print('{}'.format('s'))


print('asdf',"zxv",sep="  ",end="\n\n")
print('asdf',"zxv")


'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
