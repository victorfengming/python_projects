#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<>
#
# a = 5
# char = 'qw'+'q2w'+str(a)
# # print(char)
# print(char,a)
#

''
""
''''''
""""""
str1 = 'YOU HURT MY HEAART deepl! 1314 爱'

for i in str1:
    # if i.isupper():
        print(i,end="")
        # print(i)








'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
