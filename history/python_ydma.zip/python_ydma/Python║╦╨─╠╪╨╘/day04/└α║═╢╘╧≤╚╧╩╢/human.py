class Human:
    #属性
    sex = '男'       #性别
    age = 25         #年龄
    name = '张三'    #名字
    height = '178cm' #身高
    weight = '90kg'  #体重
    color = None
    #.....

    #方法
    #吃饭
    def eat(self):
        print('吃饭功能')

    #喝水
    def drink(self):
        print('喝水功能')

    #学习
    def study(self):
        print('学习功能')

    #...