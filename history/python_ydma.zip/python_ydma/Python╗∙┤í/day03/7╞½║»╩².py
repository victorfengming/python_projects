#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

# 偏函数 是为了更改函数默认值的特殊函数

# # 回忆
# print("###############")
# print("@@@@@@@@@@@@@@@")
# print("$$$$$$$$$$$$$$$")
#
# # help(print)
# print("###############",end="")
# print("@@@@@@@@@@@@@@@",end="")
# print("$$$$$$$$$$$$$$$",end="")

# 定义一个偏函数2(
# 导入包
# import functools
# print2 = functools.partial(print,end="*")
# # print2和print 函数功能没有任何区别,只是更改了end 的默认值
#
# print2("###############")
# print2("@@@@@@@@@@@@@@@")
# print2("$$$$$$$$$$$$$$$")
#
# #
# import functools
#
# print3 = functools.partial(print,end = "@$#%")
#
# print3("SDK")







