#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<>

# for i in range(1,31):
#     if i%5:
#         print(i,end="")
#     else:
#         print(i)

def age(**dict1):
    total = 0
    for key in dict1:
        total += dict1[key]
    print(total)
age(徐凤年= 22 ,徐骁= 55 , 徐龙象= 18)




'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
