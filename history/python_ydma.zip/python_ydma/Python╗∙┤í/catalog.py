
# 进入Python3.7的精彩世界
class 第一章:
    def python起源(self):
        pass
    def python的应用场合(self):
        pass
    def 从2_7到3_7python的新特性(self):
        pass
    def 如何学习python(self):
        pass
    def python环境的搭建(self):
        '''
         在Windows系统中安装python
         在Linux、Unix系统和Mac中安装python
         其他版本
         pass'''
    def 从HelloWorld开始(self):
        pass
    def 调试(self):
        pass
    def 问题解答(self):
        pass
    def 温故知新_学以致用(self):
        pass

# 开启python之旅
class 第二章:
    def 认识程序(self):
        def 程序():
            pass
        def 调试():
            pass
        def 语法错误():
            pass
        def 语义错误def ():
            pass
        pass
    def 数据类型(self):
        pass
    def 变量和关键字(self):
        pass
    def 语句(self):
        pass
    def 表达式(self):
        pass
    def 运算符和操作对象(self):
        pass
    def 字符串操作(self):
        pass
    def 注释(self):
        pass
    def 牛刀小试_久久乘法表实现(self):
        pass
    def 调试(self):
        pass
    def 问题解答(self):
        pass
    def 温故知新_学以致用(self):
        pass

