# BootStrap

> 简单、直观、强悍的前端开发框架，让web开发更迅速、简单。 来自Twitter，是目前很受欢迎的前端框架之一。 Bootrstrap是基于HTML、CSS、JavaScript的，让书写代码更容易。 移动优先，响应式布局开发。
>
> bootstrap中文网址：[http://www.bootcss.com/](http://www.bootcss.com/)



