#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming



'''
确定的一组无序的数据就是集合
特点:
    集合中的所有数据都是唯一的
    集合中的所有数据都没有顺序
    集合中的数据只是一次性数据,如果有多个,只保留一份
    集合可以存放的数据类型:
        整数，浮点数，布尔值，复数，字符串，元组，冰冻集合
'''

#
# 创建一个空集合
# setvar = set()
# print(setvar, type(setvar))
#
#
# # 创建多个数据的集合
# setvar = {'苹果', '压力', '八宝粥', '包子', '豆浆', '油条', '包子', '豆浆', '油条'}
# print(setvar)
#
# # 验证集合中可以放哪些数据
# # setvar = {'字符串','sadf',3}
# print(setvar)
#
# # 成员检测
# res = '苹果'
# b = res in setvar
#
# print(b)




