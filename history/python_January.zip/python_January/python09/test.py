#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming


#
# for i in range(2):
#     print(i)
# for i in range(4,6):
#     print(i)
#

#
# import math
# print(math.floor(5.5))

# 拷贝不只是改变指针
# 是真的复制对象

print(5<4<6)













