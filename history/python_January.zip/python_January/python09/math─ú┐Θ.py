#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming



'''
导入math 模块
import math
注意,如果想使用某个模块的相应功能,需先导入模块,否则无法正常使用
'''

# ceil()向上取证
import math
#
# num = 5.0000000000000001
# res = math.ceil(num)
#
# # floor()向下取整
# res = math.floor(5.9999999999999999)
# print(res)
#
# # round() 四舍五入
# res = round(5.3)

# res = round(4.3)
# # 不是math模块中的函数
# # 奇进偶不进
# res = pow(4.3,2)

# res = math.pow(4,2)


# res = math.sqrt(25)

# fabs()  求一个数的绝对值
# res = math.fabs(-23)

# abs()
#
# modf()

#
# print(math.pi)
# print(math.e)
