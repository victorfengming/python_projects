#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''


'''
random()

获取0～1之间的随机小数包含0不包含1
格式：random.random()
返回值：浮点数
choice()

随机获取列表中的值
格式：random.choice(序列)
返回值：序列中的某个值
shuffle()

随机打乱序列
格式：random.shuffle(序列)
返回值：打乱顺序的序列
randrange()

获取指定范围内指定间隔的随机整数数
格式：random.randrange(开始值，结束值[，间隔值])
返回值：整数
uniform()

随机获取指定范围内的所有数值包括小数
格式：random.uniform(开始值，结束值)
返回值：随机返回范围内的所有数值(浮点型)

'''





















