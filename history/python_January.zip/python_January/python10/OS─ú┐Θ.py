#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''

import os


# listdir() 返回当前文件中的目录列表
# res = os.listdir("E:\\PycharmProjects\\python_January")

# mkdir 创建一个目录
# os.mkdir("E:\\PycharmProjects\\python_January\\python10\\testt")

# mkdirs 递归创建目录
# os.makedirs("E:\\PycharmProjects\\python_January\\python10\\tes\\sja\\sddd\\dsd\\sd")
# print(res)

# rename()更改名字
# rmdir()删一个空文件夹
# removedirs() 递归删除文件夹
# 先进如最里面的空文件夹,出来的时候删除

# 获取文件信息
# info = os.stat("E:\\PycharmProjects\\python_January\\python10\\math数学模块.py")
# print(info)

# 时间戳















