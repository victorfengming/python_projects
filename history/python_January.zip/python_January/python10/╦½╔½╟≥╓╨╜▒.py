#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''




'''
3组红球 有0到9
1组篮球    有0到9
随机选取魅族中的一个数值,获得双色球中奖号码
'''
# randrange()
#
# 获取指定范围内指定间隔的随机整数数
# 格式：random.randrange(开始值，结束值[，间隔值])

import random
# lists = []
# hong1 = random.randrange(0, 9)
# hong2 = random.randrange(0, 9)
# res = lists.append(hong1)
# while hong1 == hong2:
#     hong2 = random.randrange(0, 9)
# hong3 = random.randrange(0, 9)
# while hong3 == hong2 or hong3 == hong1:
#     hong3 = random.randrange(0, 9)
# lan = random.randrange(0, 9)
# print("本期中奖号码:",hong1, hong2, hong3, lan)
#
# # print(lists)
# # print(res)
#
# print(random.randrange(0, 9),random.randrange(0, 9),random.randrange(0, 9),random.randrange(0, 9))




one = [1,2,3,4,5,6,7,8,2,3,4,5]
random.shuffle(one)














