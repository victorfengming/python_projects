# Coding by xiaoming
# -*- coding:utf-8 -*-

# 判断一个数能否被3整除,并且被2整除

# num = int(input("请输入一个数"))
# print("这个数",end = "")
# if num%2==0 :
#     print("能被2整除,",end = "")
# else :
#     print("不能被2整除,",end = "")
# print("并且",end = "")
# if num%3==0 :
#     print("能被3整除")
# else:
#     print("不能被3整除")

# print("今天天气不错，心情挺好，下午有课")
# print("今天天气不错，心情挺好，下午有课")
# print("今天天气不错，心情挺好，下午有课")
# 循环可以提升代码的利用率,有助于提升代码的维护.
# while True:
#     print("always")
'''循环基本格式
while 条件:
    python代码
'''
# while

# print(sum(range(1,101)))
# print("ok")
#









#
# i = 1
# sum = 0
# while i<=100:
#     sum = sum + i
#     i += 1
# print(sum)
#
'''

\(在行尾时)	续行符
\\	反斜杠符号
\'	单引号
\"	双引号
\a	响铃
\b	退格(Backspace)
\e	转义
\000	空
\n	换行
\v	纵向制表符
\t	横向制表符
\r	回车
\f	换页
\oyy	八进制数，yy代表的字符，例如：\o12代表换行
\xyy	十六进制数，yy代表的字符，例如：\x0a代表换行
\other	其它的字符以普通格式输出
'''


