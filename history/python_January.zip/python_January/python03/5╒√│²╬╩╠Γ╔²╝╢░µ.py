num = int(input("请输入一个数"))
print("不能被2整除" if num % 2 else "能被2整除")
print("不能被3整除" if num % 3 else "能被3整除")

