#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

# 普通收集参数的传递
# def mysum(a,b,c,d):
#     print(a+b+c+d)
#
# def test(*args):
#     print(args)
#     pass
#
#     # 拆包
#     print(*args)
#     # mysum(1,2,3,4)
#     # mysum(args[0],args[1],args[2],args[3])
#     mysum(*args)
#
# test(1,2,3,4)
#

#
# # 关键字收集参数的传递
# def mysum(a,b):
#     print(a)
#     print(b)
#
# def test(**kwargs):
#     print(kwargs)
#
#     # 拆包操作
#     # 应该使用两个** 进行拆包操作
#     # print(**kwargs)
#     mysum(**kwargs)
#
# test(a = 1,b = 2)













