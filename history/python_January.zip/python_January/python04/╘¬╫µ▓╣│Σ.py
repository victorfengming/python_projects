#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming


c = (2,)
print(c)
print(type(c))
# 这是元祖

c = (2)
print(c)
print(type(c))
# 这是整形





















