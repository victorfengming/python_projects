#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

# 辽东学院
# lis = [1,3,4,5,67,8,23,12]
#
# for i in lis:
#     print(lis)
#     if i == 5:
#         print("ok")
#         lis.remove(i)
#     else:
#         print("no")

# tu = ("alex",[11,22,{"k1":"v1","k2":["age","name"],"k3":(11,22,33)},44])
# tu[1] = "ALEX"

# c = (2,)
# print(c)
# print(type(c))

lists = [[],[1],[2,3,4],[6,8],[9,12]]

for i in range(4):
    if len(lists[i]) == 3:
        print("ok")
    else:
        print("no")












