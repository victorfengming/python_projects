#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming

# 本模块的功能:<用于写入文件>


from urllib.request import *
from requests import *
from re import *
from os import *
from random import *

def save_pic(pic_url,lujing):
    '''
    保存图片
    :return:
    '''

    urlretrieve(pic_url,lujing)













'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
