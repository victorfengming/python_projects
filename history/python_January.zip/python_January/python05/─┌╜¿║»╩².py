#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming
# 内建函数
'''
# 类型相关：
    int()
    # 创建或转换成整型
    float()
    # 创建或转换成浮点型
    bool()
    # 创建或转换成布尔型
    complex()
    # 创建或转换成复数型
    str()
    # 创建或转换成字符型
    list()
    # 创建或转换成列表型
    tuple()
    # 创建或转换成元组型
    set()
    # 创建或转换成集合型
    dict()
    # 创建或转换成字典型
变量相关：
    id()
    获取变量的id标志
    type()
    获取变量的类型
    print()
    打印变量的值
    locals()
    打印当前环境中所有变量

    '''

a = 'sdhf'

b = 2

c = True

locals()


















