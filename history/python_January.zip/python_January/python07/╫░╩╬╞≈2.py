#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming
#
# 装饰带有参数的函数的装饰器,
#     参数多个
#     参数不定长
#     参数不定类型
# 装饰带有返回值的函数的装饰器
# 装饰器带有参数的装饰器




















