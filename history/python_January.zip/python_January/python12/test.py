#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Created by xiaoming
from urllib import request
j = 4
i = 'http://img10.360buyimg.com/n7/jfs/t28342/75/1081261654/358322/eb65bdb9/5c061e1cN031f8fe9.jpg'
request.urlretrieve(i, str(j) + '.jpg')
'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
