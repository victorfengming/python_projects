#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming
# char = "sdkajgk"
# result = char.rfind("d")
# print(result)
#
# char.rindex()
#
# result = char.rindex("a")
# print(result)
# char.isalnum()
#
# char.isalpha()
#
# char.isdigit()
#
# char.isnumeric()
#
# char.isdecimal()
#55
# char.isspace()
#
# char.istitle()
#
# char = "\n撒顶级大,颗加,快速度,垃圾啊"
# # char.split()
# #返回一个列表
# result = char.split(",")
# print(result)
# char.splitlines()
#
# char.join()
#
# char.zfill()
#
# char.center()
#
# char.ljust()
#
# char.rjust()
#

# char.strip()
#
# char.lstrip()
#
# char.rstrip()
# #
#
# char = "qwertyuiopasdfghjklzxcvbnm"
# # char.maketrans()
# #
# result = char.maketrans("abc","def")
# # 返回一个字典,字典的键就是要替换的字符对应ASCII码的值,键对应的值就是替换的字符的ASCII吗
# print(result)
# # char.translate()
# r = char.translate(result)
# print(r)
# #
# #
# #
# #
# result = char.replace("q","w")
# print(result)
#
#
mystr = "我有一个小毛驴,从来都不骑,as宽带连接管理会计给的会计师拉杆夹看了十几个 "
str1 = bytes.maketrans(b'abco',b"ABCO")
print(str1)
str2 = "hello Word"
result = str2.translate(str1)
print(result)



a = b"sdjahjgka"
b = 1010













