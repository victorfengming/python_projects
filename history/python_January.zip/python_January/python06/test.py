#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

user1 = [[0,0],[0,8],[0,1],[0,7],[2,1],[2,7],[0,2],[0,6],[0,3],[0,5],[3,0],[3,2],[3,4],[3,6],[3,8],[0,4]]
user2 = [[9,0],[9,8],[9,1],[9,7],[7,1],[7,7],[9,2],[9,6],[9,3],[9,5],[6,0],[6,2],[6,4],[6,6],[6,8],[9,4]]

current_user = user1
other_user = user2


current_user[0] = [-1,-1]
print(current_user)
print(user1)



















