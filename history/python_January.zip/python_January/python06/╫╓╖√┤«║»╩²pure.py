#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming
char = ""
char.rfind()

char.rindex()

char.isalnum()

char.isalpha()

char.isdigit()

char.isnumeric()

char.isdecimal()

char.isspace()

char.istitle()

char.split()

char.splitlines()

char.join()

char.zfill()

char.center()

char.ljust()

char.rjust()

char.strip()

char.lstrip()

char.rstrip()

char.maketrans()

char.translate()





















