#property的作用,装饰器
优化{
	property
		作用
			将一些"'属性'的操作方法"关联到某一个属性中
		概念补充
		property
	}	
pycharm中的系统说了
	property是一个类,传递四个参数,
	将一个属性的几个操作方法关联到某一个属性里面,然后返回一个属性
	
	property(fget = None,fset = None,fdel = None,doc = None,)
	property(,FGET = None,)
property

	
