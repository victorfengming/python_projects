# import demo
# print(demo.a)

# 这就跨模块访问 了
from demo import *
# print(a)
a = 3
print(a)
#这样直接用就行了
#厉害了,这一个print能打印出来两个东西,神奇吧


