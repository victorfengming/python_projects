# import demo
# print(demo._a)

from demo import *
print(_a)

# 报错了 ,就 不好使 