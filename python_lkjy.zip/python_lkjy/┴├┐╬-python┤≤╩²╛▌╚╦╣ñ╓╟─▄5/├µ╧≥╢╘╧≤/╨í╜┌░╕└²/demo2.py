result = 0
def first_value(n):
    global result
    result = n
def jia(n):
    global result
    result +=n
def jian(n):
    global result
    result -=n
def cheng(n)
    global result
    result *=n
def chu(n):
    global result
    result /=n
first_value(2)
print(result)
jia(2)
print(result)
jian(1)
print(result)
cheng(4)
print(result)
chu(5)
print(result)