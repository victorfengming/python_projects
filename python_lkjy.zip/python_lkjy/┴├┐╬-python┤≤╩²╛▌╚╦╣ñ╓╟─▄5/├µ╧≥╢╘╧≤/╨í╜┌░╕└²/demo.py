def jia( n1 , n2):
    return n1 + n2

def jian( n1 , n2 ):
    return n1 - n2

def cheng( n1 , n2 ):
    return n1 * n2

def chu(n1 , n2 ):
    return n1/n2

res = jia(2,3)
print(res)
res2 = cheng(5,6)1
print(res2)

