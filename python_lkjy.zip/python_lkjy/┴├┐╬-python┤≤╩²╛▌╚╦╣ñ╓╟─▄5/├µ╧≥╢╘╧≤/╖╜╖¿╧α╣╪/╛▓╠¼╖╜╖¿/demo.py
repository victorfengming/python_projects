# # 实例方法传的第一个参数是一个实例
# # 类方法传的第一个参数是一个类
# #
# l = [1,4,2,3,8,5]
# #我现在想对这个列表排序
# #第一个方法：
# # sorted(l)
# l.sort(l)
# print(list)
class Person:
    @staticmethod
    @
    def jingtai():
        print("这是一个静态方法")
        pass

Person.jingtai()
p = Person()
p.jingtai()
