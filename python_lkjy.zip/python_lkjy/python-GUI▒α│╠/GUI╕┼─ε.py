# GUI 图形化用户接口
print("sdkagj")