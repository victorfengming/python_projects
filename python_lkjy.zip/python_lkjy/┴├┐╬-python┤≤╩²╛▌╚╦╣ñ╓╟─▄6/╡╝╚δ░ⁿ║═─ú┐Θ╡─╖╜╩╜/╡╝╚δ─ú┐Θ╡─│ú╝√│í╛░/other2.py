#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

# 本模块的功能:<>

o1 = "ooo1"
o2 = "ooo2"

import 循环导入
print(循环导入.t1)
print(循环导入.t2)











'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
