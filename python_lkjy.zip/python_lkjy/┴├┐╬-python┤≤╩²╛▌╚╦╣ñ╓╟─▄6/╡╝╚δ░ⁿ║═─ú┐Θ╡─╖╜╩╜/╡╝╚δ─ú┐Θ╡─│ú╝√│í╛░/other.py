#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

# 模块的功能:<>

# 100000000行代码 很多很多对象需要创建,加载时间很长
num1 = 4
num2 = 7

print("other模块被导入")













'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
