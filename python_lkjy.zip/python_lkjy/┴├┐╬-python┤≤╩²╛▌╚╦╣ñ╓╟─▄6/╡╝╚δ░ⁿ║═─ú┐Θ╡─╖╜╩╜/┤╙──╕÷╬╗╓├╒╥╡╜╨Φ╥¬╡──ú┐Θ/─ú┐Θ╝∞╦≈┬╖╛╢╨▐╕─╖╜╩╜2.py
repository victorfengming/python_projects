#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

# 模块的功能:<添加用户环境变量>

# 在用户的换环境变量中添加一个变量
#     变量名:PYTHONPATH
#     变量值:目录的路径

import demo

print(demo.name)

# 在pycharm中还需要再设置添加一下路径,才能添加到用户的环境变量








'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''
