#!/usr/bin/env python
# -*- coding:utf-8 -*-
# coding by xiaoming

'''
当你的才华还撑不起你的野心时,那你就应该静下心来学习
当你的能力还驾驭不了你的目标时,那就应该沉下心来历练
'''

import p1

# 当导入p1包的时候,自动执行了__init__.py文件里的内容了
# 然而__init__.py中写了导入的方法,所以可以导入对应模块
# 这样导入,啥也导入不进来
print(p1.Tool.num)






















